# HProductividad_WIN
Esta sección es creada para mis alumnas de Women IN de la BUAP
para la sesión 2 y 3 del modulo de Herramientas de productividad
del curso de Ciencias de datos.
